let dificuldade = document.getElementById("dificuldade");
function Cronometro() {
	let tempo = document.getElementById("tempo-jogado");
	let i = 0;
	cronometro = setInterval(() => {
		i++;
		tempo.innerText = i;
	}, 1000);
}

document.querySelector("section").oncontextmenu = function () {
	return false;
};

document.addEventListener("DOMContentLoaded", ()=>{ Main(9,9,5)});

dificuldade.addEventListener("change", ()=>{
        blocoBomba = {
            "facil": ()=>{Main(9,9,10)},
            "medio": ()=>{Main(16,16,50)},
            "dificil": ()=>{Main(50,50,350)},
            "mDificil": ()=>{Main(100, 100, 1000)},
            "personalizado": ()=>{console.log("Só executa mesmo")}
        }
    
        if (blocoBomba[dificuldade.value]){
            blocoBomba[dificuldade.value]();
        }
});